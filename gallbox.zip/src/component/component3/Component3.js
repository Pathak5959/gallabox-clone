import React, { useEffect, useState } from "react";
import "./Component3.css";
import meta from "../../assets/meta.svg";
import img1 from "../../assets/img1.webp";
import img2 from "../../assets/img2.webp";
import img3 from "../../assets/img3.webp";
import img4 from "../../assets/img4.webp";
import waa from "../../assets/waa.svg";
export default function Component3() {



  return (
    <>
      <div className="wtsp-tag">
        <div className="wtsp-heading">
          <h1>
            Powered by Official WhatsApp Business API
            <span className="wtsp-img">
              {" "}
              <img src={waa} />
            </span>
          </h1>
        </div>
        <div>
          <img src={meta} />
        </div>
      </div>
      <div className="big-text">
        <h1>
          <span className="home-head-convo">Turn your WhatsApp</span>
          <br />
          <span className="home-head-convo">
            conversations into{" "}
            <div className="slider-container">
              <div className="slider-content">
                <p>fans</p>
                <p>orders</p>
                <p>deals</p>
                <p>bookings</p>
                <p>leads</p>
              </div>
            </div>
          </span>
        </h1>
        <div className="below-text">
          Unlock the power of bots with the ease of messaging to grow sales and
          delight customers.
        </div>
        <div>
          <button className="start-free-button-1">Sign up for free</button>
        </div>
      </div>
      <div>
        <path
          stroke-linecap="round"
          stroke-linejoin="miter"
          fill-opacity="0"
          stroke-miterlimit="4"
          stroke="rgb(15,30,50)"
          stroke-opacity="1"
          stroke-width="10"
          d=" M-73.6449966430664,85.28299713134766 C-60.097999572753906,89.2770004272461 -45.09199905395508,90.4469985961914 -28.291000366210938,88.16300201416016 C133.59500122070312,66.15899658203125 356.77801513671875,-210.46200561523438 462.0830078125,-232.46600341796875 C567.3870239257812,-254.47000122070312 570.531982421875,0.14800000190734863 774.85400390625,122.74099731445312"
        ></path>
      </div>
      <div className="show-img">
      <div className="show-img-show">
          <img src={img1} />
        </div>
        <div className="show-img-show">
          <img src={img2} />
        </div>
        <div className="show-img-show">
          <img src={img3} />
        </div>
        <div className="show-img-show">
          <img src={img4} />
        </div>
      </div>
    </>
  );
}
