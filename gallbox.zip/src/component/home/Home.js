import React from "react";
import "./Home.css";
export default function Home() {
  return (
    <>
      <div className="blue-header-top">
        <div class="header-top">
          Instantly Craft Perfect WhatsApp Templates with AI Assistance✨
          <span>
            <button className="try-now-butn">Try now</button>
          </span>
        </div>
      </div>
    </>
  );
}
