import React, { useState } from "react";
import "./GallaboxHeader.css";
import gallabox from "../../assets/gallabox.svg";
import dropdown from "../../assets/dropdown.svg";
import blog from "../../assets/blog.svg";
import docs from "../../assets/docs.svg";
import Bot from "../../assets/Bot.svg";
import Case from "../../assets/Case.svg";
export default function GallaboxHeader() {
  const [hoveredItem, setHoveredItem] = useState(null);

  const handleMouseEnter = (item) => {
    setHoveredItem(item);
  };

  const handleMouseLeave = () => {
    setHoveredItem(null);
  };

  const renderPopupContent = (item) => {
    switch (item) {
      case "Features":
        return (
          <div className="popup-content">
            <div className="item-box-flex1">
              <div className="item-box-flex-child">
                <div>
                  <img src={blog} className="" alt="Gallabox Logo" />
                </div>

                <div className="text-msg1">
                  {" "}
                  <span className="text-msg2-heading ">Blog </span>
                  <br />
                  <div>Reach Customer on their preferred messaging channel</div>
                </div>
              </div>
              <div className="item-box-flex-child">
                <div>
                  <img src={docs} className="" alt="Gallabox Logo" />
                </div>

                <div className="text-msg1">
                  {" "}
                  <span className="text-msg2-heading ">Docs </span>
                  <br />
                  <div>
                    A quick overview of Gallabox to help you understand &
                    automate your business
                  </div>
                </div>
              </div>
            </div>
            <div className="item-box-flex1">
              <div className="item-box-flex-child">
                <div>
                  <img src={Bot} className="" alt="Gallabox Logo" />
                </div>

                <div className="text-msg1">
                  {" "}
                  <span className="text-msg2-heading ">Bot Templates </span>
                  <br />
                  <div>Build no-code bots to serve customers 24/7</div>
                </div>
              </div>
              <div className="item-box-flex-child">
                <div>
                  <img src={Case} className="" alt="Gallabox Logo" />
                </div>

                <div className="text-msg1">
                  {" "}
                  <span className="text-msg2-heading ">Case Studies </span>
                  <br />
                  <div>
                    Learn how Gallabox is helping businesses meet business goals
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      case "Industries":
        return   <div className="popup-content">
        <div className="item-box-flex1">
          <div className="item-box-flex-child">
            <div>
              <img src={blog} className="" alt="Gallabox Logo" />
            </div>

            <div className="text-msg1">
              {" "}
              <span className="text-msg2-heading ">Blog </span>
              <br />
              <div>Reach Customer on their preferred messaging channel</div>
            </div>
          </div>
          <div className="item-box-flex-child">
            <div>
              <img src={docs} className="" alt="Gallabox Logo" />
            </div>

            <div className="text-msg1">
              {" "}
              <span className="text-msg2-heading ">Docs </span>
              <br />
              <div>
                A quick overview of Gallabox to help you understand &
                automate your business
              </div>
            </div>
          </div>
        </div>
        <div className="item-box-flex1">
          <div className="item-box-flex-child">
            <div>
              <img src={Bot} className="" alt="Gallabox Logo" />
            </div>

            <div className="text-msg1">
              {" "}
              <span className="text-msg2-heading ">Bot Templates </span>
              <br />
              <div>Build no-code bots to serve customers 24/7</div>
            </div>
          </div>
          <div className="item-box-flex-child">
            <div>
              <img src={Case} className="" alt="Gallabox Logo" />
            </div>

            <div className="text-msg1">
              {" "}
              <span className="text-msg2-heading ">Case Studies </span>
              <br />
              <div>
                Learn how Gallabox is helping businesses meet business goals
              </div>
            </div>
          </div>
        </div>
      </div>;
      case "Integrations":
        return   <div className="popup-content">
        <div className="item-box-flex1">
          <div className="item-box-flex-child">
            <div>
              <img src={blog} className="" alt="Gallabox Logo" />
            </div>

            <div className="text-msg1">
              {" "}
              <span className="text-msg2-heading ">Blog </span>
              <br />
              <div>Reach Customer on their preferred messaging channel</div>
            </div>
          </div>
          <div className="item-box-flex-child">
            <div>
              <img src={docs} className="" alt="Gallabox Logo" />
            </div>

            <div className="text-msg1">
              {" "}
              <span className="text-msg2-heading ">Docs </span>
              <br />
              <div>
                A quick overview of Gallabox to help you understand &
                automate your business
              </div>
            </div>
          </div>
        </div>
        <div className="item-box-flex1">
          <div className="item-box-flex-child">
            <div>
              <img src={Bot} className="" alt="Gallabox Logo" />
            </div>

            <div className="text-msg1">
              {" "}
              <span className="text-msg2-heading ">Bot Templates </span>
              <br />
              <div>Build no-code bots to serve customers 24/7</div>
            </div>
          </div>
          <div className="item-box-flex-child">
            <div>
              <img src={Case} className="" alt="Gallabox Logo" />
            </div>

            <div className="text-msg1">
              {" "}
              <span className="text-msg2-heading ">Case Studies </span>
              <br />
              <div>
                Learn how Gallabox is helping businesses meet business goals
              </div>
            </div>
          </div>
        </div>
      </div>;
      case "Resources":
        return   <div className="popup-content">
        <div className="item-box-flex1">
          <div className="item-box-flex-child">
            <div>
              <img src={blog} className="" alt="Gallabox Logo" />
            </div>

            <div className="text-msg1">
              {" "}
              <span className="text-msg2-heading ">Blog </span>
              <br />
              <div>Reach Customer on their preferred messaging channel</div>
            </div>
          </div>
          <div className="item-box-flex-child">
            <div>
              <img src={docs} className="" alt="Gallabox Logo" />
            </div>

            <div className="text-msg1">
              {" "}
              <span className="text-msg2-heading ">Docs </span>
              <br />
              <div>
                A quick overview of Gallabox to help you understand &
                automate your business
              </div>
            </div>
          </div>
        </div>
        <div className="item-box-flex1">
          <div className="item-box-flex-child">
            <div>
              <img src={Bot} className="" alt="Gallabox Logo" />
            </div>

            <div className="text-msg1">
              {" "}
              <span className="text-msg2-heading ">Bot Templates </span>
              <br />
              <div>Build no-code bots to serve customers 24/7</div>
            </div>
          </div>
          <div className="item-box-flex-child">
            <div>
              <img src={Case} className="" alt="Gallabox Logo" />
            </div>

            <div className="text-msg1">
              {" "}
              <span className="text-msg2-heading ">Case Studies </span>
              <br />
              <div>
                Learn how Gallabox is helping businesses meet business goals
              </div>
            </div>
          </div>
        </div>
      </div>;
      case "Free Tools":
        return   <div className="popup-content">
        <div className="item-box-flex1">
          <div className="item-box-flex-child">
            <div>
              <img src={blog} className="" alt="Gallabox Logo" />
            </div>

            <div className="text-msg1">
              {" "}
              <span className="text-msg2-heading ">Blog </span>
              <br />
              <div>Reach Customer on their preferred messaging channel</div>
            </div>
          </div>
          <div className="item-box-flex-child">
            <div>
              <img src={docs} className="" alt="Gallabox Logo" />
            </div>

            <div className="text-msg1">
              {" "}
              <span className="text-msg2-heading ">Docs </span>
              <br />
              <div>
                A quick overview of Gallabox to help you understand &
                automate your business
              </div>
            </div>
          </div>
        </div>
        <div className="item-box-flex1">
          <div className="item-box-flex-child">
            <div>
              <img src={Bot} className="" alt="Gallabox Logo" />
            </div>

            <div className="text-msg1">
              {" "}
              <span className="text-msg2-heading ">Bot Templates </span>
              <br />
              <div>Build no-code bots to serve customers 24/7</div>
            </div>
          </div>
          <div className="item-box-flex-child">
            <div>
              <img src={Case} className="" alt="Gallabox Logo" />
            </div>

            <div className="text-msg1">
              {" "}
              <span className="text-msg2-heading ">Case Studies </span>
              <br />
              <div>
                Learn how Gallabox is helping businesses meet business goals
              </div>
            </div>
          </div>
        </div>
      </div>;
      default:
        return null;
    }
  };

  return (
    <div className="second-header">
      <div>
        <img src={gallabox} className="logo-height" alt="Gallabox Logo" />
      </div>
      {[
        "Features",
        "Industries",
        "Integrations",
        "Resources",
        "Free Tools",
      ].map((item) => (
        <div
          key={item}
          className="text-name-container"
          onMouseEnter={() => handleMouseEnter(item)}
          onMouseLeave={handleMouseLeave}
        >
          <div className="text-name">
            {item}{" "}
            <span>
              <img className="drop-down" src={dropdown} alt="Dropdown Icon" />
            </span>
            {item === "Free Tools" && (
              <button className="new-button">New</button>
            )}
          </div>
          {hoveredItem === item && (
            <div className="popup">{renderPopupContent(item)}</div>
          )}
        </div>
      ))}
      <div className="text-name1">Pricing</div>
      <div className="text-name">Login</div>
      <div className="text-name">
        <button className="start-free-button">Start Free Trial</button>
      </div>
    </div>
  );
}
