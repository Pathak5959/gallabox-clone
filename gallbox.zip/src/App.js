import "./App.css";
import Component3 from "./component/component3/Component3";
import GallaboxHeader from "./component/gallaboxHeader/GallaboxHeader";
import Home from "./component/home/Home";

function App() {
  return (
    <>
      <Home />
      <div className="point">
      <GallaboxHeader />
      <Component3 />
      </div>
      
    </>
  );
}

export default App;
